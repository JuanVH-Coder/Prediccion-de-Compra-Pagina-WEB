import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
from sklearn.svm import SVC


# Cargar los datos y preprocesamiento
data = pd.read_csv('SVM.csv', delimiter=';')
data.dropna(inplace=True)



# Normalización de datos
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data[['Acceso a la pagina', 'Tiempo en la pagina', 'Agregacion al carrito', 'Compra del producto']])
data_normalized = pd.DataFrame(data_scaled, columns=['Acceso a la pagina', 'Tiempo en la pagina', 'Agregacion al carrito', 'Compra del producto'])

# Análisis exploratorio de datos
# Histogramas para cada característica
plt.figure(figsize=(12, 12))
for i, column in enumerate(data_normalized.columns):
    plt.subplot(2, 2, i + 1)
    sns.histplot(data_normalized[column], kde=True)
    plt.title(f'Histograma de {column}')
plt.tight_layout()
plt.show()

# Crear una secuencia de índices para los datos
indices = range(len(data))

# Encontrar el tiempo máximo y mínimo en la columna "Tiempo en la página"
tiempo_maximo = data['Tiempo en la pagina'].max()

# Calcular la media, mediana y desviación estándar del tiempo en la página
tiempo_media = data['Tiempo en la pagina'].mean()
tiempo_mediana = data['Tiempo en la pagina'].median()
tiempo_desviacion_estandar = data['Tiempo en la pagina'].std()

# Imprimir los resultados
print("DATOS DEL TIEMPO EN LA PAGINA :")
print("Tiempo máximo en la página:", tiempo_maximo)
print("Media del tiempo en la página:", tiempo_media)
print("Mediana del tiempo en la página:", tiempo_mediana)
print("Desviación estándar del tiempo en la página:", tiempo_desviacion_estandar)

plt.figure(figsize=(8, 6))
sns.histplot(data['Tiempo en la pagina'], kde=True, bins=20)
plt.title('Histograma del Tiempo en la Página')
plt.xlabel('Tiempo en la Página')
plt.ylabel('Frecuencia')
plt.show()


# Graficar el tiempo en la página
plt.figure(figsize=(10, 6))
plt.bar(indices, data['Tiempo en la pagina'], color='skyblue')
plt.title('Tiempo en la página')
plt.xlabel('Índice')
plt.ylabel('Tiempo en la página')
plt.xticks(indices, rotation=45)
plt.tight_layout()
plt.show()


# Calcular el máximo, la media y el mínimo del tiempo de acceso a la página
max_acceso_pagina = data['Acceso a la pagina'].max()
mean_acceso_pagina = data['Acceso a la pagina'].mean()
min_acceso_pagina = data['Acceso a la pagina'].min()


print("DATOS ACCESO DE LA PAGINA :")
print("Máximo de acceso a la página:", max_acceso_pagina)
print("Media de acceso a la página:", mean_acceso_pagina)



plt.figure(figsize=(8, 6))
# Gráfico de barras para 'Acceso a la pagina'
sns.countplot(x='Acceso a la pagina', data=data, palette='pastel')
plt.title('Acceso a la página')
plt.tight_layout()
plt.show()


# Contar los valores en la columna 'Agregacion al carrito'
counts_agregacion = data['Agregacion al carrito'].value_counts()

# Contar los valores en la columna 'Compra del producto'
counts_compra = data['Compra del producto'].value_counts()

print("Agregacion al carrito:")
print(counts_agregacion)

print("\nCompra del producto:")
print(counts_compra) 

plt.figure(figsize=(10, 5))

# Gráfico de barras para 'Agregacion al carrito'
plt.subplot(1, 2, 1)
sns.countplot(x='Agregacion al carrito', data=data, palette='pastel')
plt.title('Agregacion al carrito')

# Gráfico de barras para 'Compra del producto'
plt.subplot(1, 2, 2)
sns.countplot(x='Compra del producto', data=data, palette='pastel')
plt.title('Compra del producto')

plt.tight_layout()
plt.show()

# Visualizar la relación entre la compra del producto y el acceso a la página
plt.figure(figsize=(8, 6))
sns.scatterplot(x='Acceso a la pagina', y='Compra del producto', data=data)
plt.title('Relación entre la compra del producto y el acceso a la página')
plt.xlabel('Acceso a la página')
plt.ylabel('Compra del producto')
plt.show()

# Visualizar la relación entre la compra del producto y el TIEMPO EN LA PAGINA
plt.figure(figsize=(8, 6))
sns.scatterplot(x='Tiempo en la pagina', y='Compra del producto', data=data)
plt.title('Relación entre la compra del producto y el tiempo en la página')
plt.xlabel('Tiempo en la página')
plt.ylabel('Compra del producto')
plt.show()







###############################################################################################################################################









# Dividir los datos en conjunto de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(data_normalized, data['Compra del producto'], test_size=0.2, random_state=100)

# Entrenar el modelo SVM
model = SVC(kernel='rbf', C=10, gamma='scale', probability=True)  # Puedes ajustar los hiperparámetros según sea necesario
model.fit(X_train, y_train)

# Realizar predicciones de probabilidad en el conjunto de prueba
y_pred_proba = model.predict_proba(X_test)

# Iterar sobre las probabilidades de predicción
print("Probabilidades de Predicción:")
for prob in y_pred_proba:
    print(prob)

# Obtener las distancias de las muestras al hiperplano de separación
distances = model.decision_function(X_test)



# Obtener las predicciones de clase a partir de las probabilidades
y_pred = model.predict(X_test)

# Visualizar las probabilidades de predicción
plt.figure(figsize=(10, 6))
plt.scatter(y_pred_proba[:, 0], y_pred_proba[:, 1], c=y_test, cmap='coolwarm')
plt.xlabel('Probabilidad de no compra del producto')
plt.ylabel('Probabilidad de compra del producto')
plt.title('Probabilidades de Predicción')
plt.colorbar(label='Clase real')
plt.show()


# Calcular los verdaderos positivos, verdaderos negativos, falsos positivos y falsos negativos
vp = sum((y_pred == 1) & (y_test == 1))
vn = sum((y_pred == 0) & (y_test == 0))
FP = sum((y_pred == 1) & (y_test == 0))
FN = sum((y_pred == 0) & (y_test == 1))

# Crear la matriz de confusión
print(f"Verdaderos positivos (VP): {vp}")
print(f"Verdaderos positivos (VP): {vn}")
print(f"Falsos positivos (FP): {FP}")
print(f"Falsos Negativos (FN): {FN}")
conf_matrix = pd.DataFrame({'Verdaderos positivos (VP): No Compra': [vn, FP], 'Verdaderos positivos (VP): Compra': [FN, vp]}, index=['Predicción: No Compra', 'Predicción: Compra'])

# Mostrar la matriz de confusión
print("Matriz de Confusión:")
print(conf_matrix)

# Evaluar el modelo con las predicciones de clase
print("Matriz de Confusión:")
print(confusion_matrix(y_test, y_pred))
print("\nReporte de Clasificación:")
print(classification_report(y_test, y_pred))


# Obtener las distancias de las muestras al hiperplano de separación
distances = model.decision_function(X_test)

# Visualizar la relación entre la distancia y la probabilidad para la clase 1
plt.figure(figsize=(10, 6))
plt.scatter(distances, y_pred_proba[:, 1], c=y_test, cmap='coolwarm')
plt.xlabel('Distancia al hiperplano de separación')
plt.ylabel('Probabilidad estimada de pertenecer a la clase 1')
plt.title('Relación entre la distancia y la probabilidad')
plt.colorbar(label='Clase real')
plt.show()


# Reducir las características a 2 dimensiones utilizando PCA
pca = PCA(n_components=2)
X_pca = pca.fit_transform(data_normalized)

# Entrenar el modelo SVM en las características reducidas
model_2d = SVC(kernel='linear')
model_2d.fit(X_pca, data['Compra del producto'])

# Visualizar el hiperplano de decisión en 3D
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Crear una malla de puntos para representar el hiperplano de decisión
x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1), np.arange(y_min, y_max, 0.1))
Z = model_2d.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plotear el hiperplano de decisión
ax.contour3D(xx, yy, Z, 50, cmap='binary', alpha=0.5)

# Plotear los datos clasificados
ax.scatter(X_pca[:, 0], X_pca[:, 1], data['Compra del producto'], c=data['Compra del producto'], cmap='viridis', edgecolor='k', s=100)
ax.set_xlabel('Componente Principal 1')
ax.set_ylabel('Componente Principal 2')
ax.set_zlabel('Compra del Producto')
ax.set_title('Hiperplano de Decisión SVM en 3D')
plt.show()




####################################################################################################################################################3





# Entrenar el modelo SVM con kernel polinómico en las características reducidas obtenidas mediante PCA
model_poly_pca_improved = SVC(kernel='poly', degree=5, C=10.0, gamma='scale', coef0=1.0, probability=True)
model_poly_pca_improved.fit(X_pca, data['Compra del producto'])

# Realizar predicciones en el conjunto de prueba
y_pred = model_poly_pca_improved.predict(X_pca)

# Calcular las métricas de evaluación
precision = precision_score(data['Compra del producto'], y_pred)
recall = recall_score(data['Compra del producto'], y_pred)
f1 = f1_score(data['Compra del producto'], y_pred)

# Calcular la matriz de confusión
conf_matrix = confusion_matrix(data['Compra del producto'], y_pred)

# Imprimir las métricas
print("EVALUACION DEL MODELO POLINOMICO:")
print("Métricas de evaluación:")
print(f"Precisión: {precision}")
print(f"Recall: {recall}")
print(f"F1-score: {f1}")

# Imprimir la matriz de confusión
print("\nMatriz de Confusión:")
print(conf_matrix)

# Obtener las probabilidades de predicción en el conjunto de datos original
y_pred_proba = model_poly_pca_improved.predict_proba(X_pca)

# Imprimir las probabilidades de predicción para las primeras 10 muestras
print("Probabilidades de Predicción para las primeras 10 muestras:")
for i in range(50):
    print(f"Muestra {i+1}: No Compra: {y_pred_proba[i, 0]}, Compra: {y_pred_proba[i, 1]}")


# Visualizar el hiperplano de decisión en 2D
plt.figure(figsize=(10, 8))
sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1], hue=data['Compra del producto'], palette='viridis', edgecolor='k', s=100)
ax = plt.gca()
xlim = ax.get_xlim()
ylim = ax.get_ylim()

# Crear una malla para visualizar el hiperplano de decisión
xx, yy = np.meshgrid(np.linspace(xlim[0], xlim[1], 50), np.linspace(ylim[0], ylim[1], 50))
Z = model_poly_pca_improved.predict(np.c_[xx.ravel(), yy.ravel()])

# Visualizar el hiperplano de decisión
Z = Z.reshape(xx.shape)
plt.contourf(xx, yy, Z, alpha=0.2, cmap='binary')

plt.xlabel('Componente Principal 1')
plt.ylabel('Componente Principal 2')
plt.title('Hiperplano de Decisión SVM con Kernel Polinómico Mejorado en Espacio Reducido')
plt.legend(loc='upper right')
plt.show()

# Visualizar el hiperplano de decisión en 3D con kernel polinómico
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Crear una malla de puntos para representar el hiperplano de decisión
x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 50), np.linspace(y_min, y_max, 50))
Z = model_poly_pca_improved.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plotear el hiperplano de decisión
ax.contour3D(xx, yy, Z, 50, cmap='binary', alpha=0.5)

# Plotear los datos clasificados
ax.scatter(X_pca[:, 0], X_pca[:, 1], data['Compra del producto'], c=data['Compra del producto'], cmap='viridis', edgecolor='k', s=100)
ax.set_xlabel('Componente Principal 1')
ax.set_ylabel('Componente Principal 2')
ax.set_zlabel('Compra del Producto')
ax.set_title('Hiperplano de Decisión SVM con Kernel Polinómico Mejorado en 3D')
plt.show()

 


########################################################################################################################################################################





# Entrenar el modelo SVM con kernel lineal en las características reducidas obtenidas mediante PCA
model_linear_pca = SVC(kernel='linear', C=25.0, probability=True)
model_linear_pca.fit(X_pca, data['Compra del producto'])

# Realizar predicciones en el conjunto de prueba
y_pred_linear = model_linear_pca.predict(X_pca)

# Calcular las métricas de evaluación
precision_linear = precision_score(data['Compra del producto'], y_pred_linear)
recall_linear = recall_score(data['Compra del producto'], y_pred_linear)
f1_linear = f1_score(data['Compra del producto'], y_pred_linear)

# Calcular la matriz de confusión
conf_matrix_linear = confusion_matrix(data['Compra del producto'], y_pred_linear)

# Imprimir las métricas
print("EVALUACION DEL MODELO LINEAL:")
print("Métricas de evaluación:")
print(f"Precisión: {precision_linear}")
print(f"Recall: {recall_linear}")
print(f"F1-score: {f1_linear}")

# Imprimir la matriz de confusión
print("\nMatriz de Confusión:")
print(conf_matrix_linear)

# Obtener las probabilidades de predicción en el conjunto de datos original
y_pred_proba_linear = model_linear_pca.predict_proba(X_pca)

# Imprimir las probabilidades de predicción para las primeras 10 muestras
print("Probabilidades de Predicción para las primeras 10 muestras:")
for i in range(50):
    print(f"Muestra {i+1}: No Compra: {y_pred_proba_linear[i, 0]}, Compra: {y_pred_proba_linear[i, 1]}")

# Visualizar el hiperplano de decisión en 2D
plt.figure(figsize=(10, 8))
sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1], hue=data['Compra del producto'], palette='viridis', edgecolor='k', s=100)
ax = plt.gca()
xlim = ax.get_xlim()
ylim = ax.get_ylim()

# Crear una malla para visualizar el hiperplano de decisión
xx, yy = np.meshgrid(np.linspace(xlim[0], xlim[1], 50), np.linspace(ylim[0], ylim[1], 50))
Z = model_linear_pca.predict(np.c_[xx.ravel(), yy.ravel()])

# Visualizar el hiperplano de decisión
Z = Z.reshape(xx.shape)
plt.contourf(xx, yy, Z, alpha=0.2, cmap='binary')

plt.xlabel('Componente Principal 1')
plt.ylabel('Componente Principal 2')
plt.title('Hiperplano de Decisión SVM con Kernel Lineal en Espacio Reducido')
plt.legend(loc='upper right')
plt.show()

# Visualizar el hiperplano de decisión en 3D con kernel lineal
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Crear una malla de puntos para representar el hiperplano de decisión
x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 50), np.linspace(y_min, y_max, 50))
Z = model_linear_pca.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plotear el hiperplano de decisión
ax.contour3D(xx, yy, Z, 50, cmap='binary', alpha=0.5)

# Plotear los datos clasificados
ax.scatter(X_pca[:, 0], X_pca[:, 1], data['Compra del producto'], c=data['Compra del producto'], cmap='viridis', edgecolor='k', s=100)
ax.set_xlabel('Componente Principal 1')
ax.set_ylabel('Componente Principal 2')
ax.set_zlabel('Compra del Producto')
ax.set_title('Hiperplano de Decisión SVM con Kernel Lineal en 3D')
plt.show()




#########################################################################################################################################################

# Entrenar el modelo SVM con kernel sigmoidal en las características reducidas obtenidas mediante PCA
model_sigmoid_pca = SVC(kernel='sigmoid', C=10.0, gamma='scale', coef0=1.0, probability=True)
model_sigmoid_pca.fit(X_pca, data['Compra del producto'])

# Realizar predicciones en el conjunto de prueba
y_pred_sigmoid = model_sigmoid_pca.predict(X_pca)

# Calcular las métricas de evaluación
precision_sigmoid = precision_score(data['Compra del producto'], y_pred_sigmoid)
recall_sigmoid = recall_score(data['Compra del producto'], y_pred_sigmoid)
f1_sigmoid = f1_score(data['Compra del producto'], y_pred_sigmoid)

# Calcular la matriz de confusión
conf_matrix_sigmoid = confusion_matrix(data['Compra del producto'], y_pred_sigmoid)

# Imprimir las métricas
print("EVALUACION DEL MODELO SIGMOIDAL:")
print("Métricas de evaluación:")
print(f"Precisión: {precision_sigmoid}")
print(f"Recall: {recall_sigmoid}")
print(f"F1-score: {f1_sigmoid}")

# Imprimir la matriz de confusión
print("\nMatriz de Confusión:")
print(conf_matrix_sigmoid)

# Obtener las probabilidades de predicción en el conjunto de datos original
y_pred_proba_sigmoid = model_sigmoid_pca.predict_proba(X_pca)

# Imprimir las probabilidades de predicción para las primeras 10 muestras
print("Probabilidades de Predicción para las primeras 10 muestras:")
for i in range(50):
    print(f"Muestra {i+1}: No Compra: {y_pred_proba_sigmoid[i, 0]}, Compra: {y_pred_proba_sigmoid[i, 1]}")

# Visualizar el hiperplano de decisión en 2D
plt.figure(figsize=(10, 8))
sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1], hue=data['Compra del producto'], palette='viridis', edgecolor='k', s=100)
ax = plt.gca()
xlim = ax.get_xlim()
ylim = ax.get_ylim()

# Crear una malla para visualizar el hiperplano de decisión
xx, yy = np.meshgrid(np.linspace(xlim[0], xlim[1], 50), np.linspace(ylim[0], ylim[1], 50))
Z = model_sigmoid_pca.predict(np.c_[xx.ravel(), yy.ravel()])

# Visualizar el hiperplano de decisión
Z = Z.reshape(xx.shape)
plt.contourf(xx, yy, Z, alpha=0.2, cmap='binary')

plt.xlabel('Componente Principal 1')
plt.ylabel('Componente Principal 2')
plt.title('Hiperplano de Decisión SVM con Kernel Sigmoidal Mejorado en Espacio Reducido')
plt.legend(loc='upper right')
plt.show()

# Visualizar el hiperplano de decisión en 3D con kernel sigmoidal
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Crear una malla de puntos para representar el hiperplano de decisión
x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 50), np.linspace(y_min, y_max, 50))
Z = model_sigmoid_pca.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plotear el hiperplano de decisión
ax.contour3D(xx, yy, Z, 50, cmap='binary', alpha=0.5)

# Plotear los datos clasificados
ax.scatter(X_pca[:, 0], X_pca[:, 1], data['Compra del producto'], c=data['Compra del producto'], cmap='viridis', edgecolor='k', s=100)
ax.set_xlabel('Componente Principal 1')
ax.set_ylabel('Componente Principal 2')
ax.set_zlabel('Compra del Producto')
ax.set_title('Hiperplano de Decisión SVM con Kernel Sigmoidal Mejorado en 3D')
plt.show()

    